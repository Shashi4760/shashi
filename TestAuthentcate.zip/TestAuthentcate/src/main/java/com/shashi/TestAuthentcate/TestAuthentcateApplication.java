package com.shashi.TestAuthentcate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestAuthentcateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestAuthentcateApplication.class, args);
	}

}
